export class Items{
  constructor( public pname:string,public pcost:number){}
}
