export class Cart {
  constructor ( public pname:string ,public pcost:number){}
}
